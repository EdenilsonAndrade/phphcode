<?php 

// exemplo de array que seria na vdd um vetor

$frutas = array("laranja", "abacaxi", "melancia");

print_r($frutas);

 ?>