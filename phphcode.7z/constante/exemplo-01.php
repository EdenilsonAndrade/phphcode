<?php 

// para criar uma constante irá utilizar o define, no primeiro campo dentro do parenteses deve ser informado o nome da constante, no segundo campo o valor da mesma

define("SERVIDOR", "127.0.0.1");

// para exibir a constante pode utilizar tbm o echo porém não será informado o $

echo SERVIDOR;

// por padrão sempre seguir as constantes com letras maiusculas

 ?>