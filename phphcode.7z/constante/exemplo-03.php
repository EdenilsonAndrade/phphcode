<?php 

// para trazer a versão do php

echo PHP_VERSION;

echo "<br>";

// para trazer uma barra de diretório, isso pode ser muito utilizado pois a barra de diretório do windows e do linux são diferentes e com isso já irá levar o correto

echo DIRECTORY_SEPARATOR;

 ?>