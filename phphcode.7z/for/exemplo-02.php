<?php 

// exemplo de for incorreto onde entra em um loop infinito

for ($i=0; $i < 10; $i--) { 
	
	echo $i;

}

 ?>