<?php 

// outro exemplo de função anonima seria declarando a função dentro de uma variavel

$fn = function($a){

	var_dump($a);

};

$fn("Oi");

 ?>