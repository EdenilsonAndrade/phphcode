<?php 

var_dump("OK");

function somar ($a, $b){

	return $a + $b;
	
}

 ?>