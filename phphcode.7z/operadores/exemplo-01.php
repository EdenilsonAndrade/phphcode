<?php

// operador de atribuição
$nome = "Hcode";

// operador de concatenização

echo $nome . " mais alguma coisa<br>";

// operador composto

$nome .= " Treinamentos";

echo $nome;

?>