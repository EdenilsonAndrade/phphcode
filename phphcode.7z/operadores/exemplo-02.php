<?php

// operador de atribuição

$valorTotal = 0;

$valorTotal +=100;

$valorTotal +=25;

// $valorTotal *= .9;

$valorTotal -= ($valorTotal * .1);

echo $valorTotal;

?>