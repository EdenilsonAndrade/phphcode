<?php

// operadores aritiméticos

$a = 10;
$b =2;

echo $a + $b;

echo "<br>";

echo $a - $b;

echo "<br>";

echo $a * $b;

echo "<br>";

echo $a / $b;

echo "<br>";

// modo que tras a diferença

echo $a % $b;

echo "<br>";

// tag a elevado a tag b
echo $a ** $b;

?>