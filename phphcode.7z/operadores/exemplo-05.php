<?php

// operador de comparação

$a = 50;

$b = 35;

// essa função spaceship verifica se as variáveis são menor, maior ou igual.
// menor = -1
// igual = 0
// maior = 1

var_dump($a <=> $b);

?>