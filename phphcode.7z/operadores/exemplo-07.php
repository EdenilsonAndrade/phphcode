<?php 

// operador de incremento

$a = 10;

// para somar mais um na variavel poderá utilizar o operador ++ conforme exemplo
// se utilizado antes da variavel irá trazer a informação já no primeiro echo, se for após a variavel só irá trazer após a segundo repetição

echo $a++;

echo "<br>";

echo $a;

// poderá tbm utilizar o operador de decremento

echo "<br>";

echo --$a;

?>