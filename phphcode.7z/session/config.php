<?php 

// neste arquivo poderá ser criado todas as configurações para sempre poder chamar o mesmo em cada arquivo

session_start();

 ?>