<?php 

// por padrão o php não inicia uma sessão automáticamente, para inciar a mesma utilizar a função abaixo

require_once("config.php");

$_SESSION["nome"] = "Hcode";

 ?>