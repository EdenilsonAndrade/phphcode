<?php 

require_once("config.php");

// para verificar o número do id da sessão utilizar a função abaixo

echo session_id();

 ?>