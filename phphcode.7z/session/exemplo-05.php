<?php 

// exemplo para recuperar uma sessão

session_id('bptjchdqld2r6dkep9aak6aoa6array');

require_once("config.php");

echo session_id();

var_dump($_SESSION);

 ?>