<?php 

$empresa = "Hcode";

// para trocar no exemplo o por 0 e o e por 3, detalhe que diferencia entre letra maiuscula e minuscula

$empresa = str_replace("o", "0", $empresa);
$empresa = str_replace("e", "3", $empresa);

echo $empresa;

 ?>